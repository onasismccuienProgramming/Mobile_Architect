package com.zybooks.project2textmessage

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        public void onRadioButtonClicked(View view) {
            // Which radio button was selected?
            switch (view.getId()) {
                case R.id.radio_yes:
                // "Yes!" selected
                break;
                case R.id.radio_no:
                // "Maybe later" selected
                break;
            }
        }

    }
}
