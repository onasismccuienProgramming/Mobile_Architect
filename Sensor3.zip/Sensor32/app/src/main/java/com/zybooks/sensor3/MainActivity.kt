package com.zybooks.sensor3

import android.R
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity(), SensorEventListener {
    private var mCompassImage: ImageView? = null
    private var mSensorManager: SensorManager? = null
    private var mAccelerometer: Sensor? = null
    private var mMagneticField: Sensor? = null
    private var mAccelValues: FloatArray
    private var mMagneticValues: FloatArray?
    private val mRotationMatrix = FloatArray(9)
    private val mOrientation = FloatArray(3)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Image has north facing up
        mCompassImage = findViewById(R.id.compassImage)
        mSensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        mAccelerometer = mSensorManager!!.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        mMagneticField = mSensorManager!!.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
    }

    override fun onSensorChanged(sensorEvent: SensorEvent) {

        // Get sensor data
        if (sensorEvent.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            mAccelValues = sensorEvent.values
        } else if (sensorEvent.sensor.type == Sensor.TYPE_MAGNETIC_FIELD) {
            mMagneticValues = sensorEvent.values
        }

        // Make sure both values have been obtained
        if (mAccelerometer != null && mMagneticValues != null) {

            // Compute rotation matrix
            if (SensorManager.getRotationMatrix(
                    mRotationMatrix,
                    null,
                    mAccelValues,
                    mMagneticValues
                )
            ) {

                // Compute orientation values
                SensorManager.getOrientation(mRotationMatrix, mOrientation)

                // Convert azimuth rotation angle from radians to degrees
                val azimuthAngle = Math.toDegrees(mOrientation[0].toDouble()).toFloat()

                // Rotate the image
                mCompassImage.setRotation(-azimuthAngle)
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, i: Int) {}
    override fun onResume() {
        super.onResume()
        mSensorManager!!.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_GAME)
        mSensorManager!!.registerListener(this, mMagneticField, SensorManager.SENSOR_DELAY_GAME)
    }

    override fun onPause() {
        super.onPause()
        mSensorManager!!.unregisterListener(this) // All sensors
    }
}